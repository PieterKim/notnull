<template>
<div>
    <h1>Test Page</h1>
    <p>이 페이지는 테스트 페이지입니다.</p>
</div>
</template>


<script>
export default{ 
    name:'',
    components:{},
    data(){
        return{

        };
    },
    setup(){},
    created(){},
    mounted(){},
    unmounted(){},
    methods:{

    },
    computed:{},
    watch:{}
}
</script>