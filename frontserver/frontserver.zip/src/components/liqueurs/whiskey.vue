<template>
<div>
    <h1>Test Page</h1>
    <p>이 페이지는 위스키 리스트입니다.</p>
</div>
</template>


<script>
export default{ 
    name:'',
    components:{},
    data(){
        return{

        };
    },
    setup(){},
    created(){},
    mounted(){},
    unmounted(){},
    methods:{

    },
    computed:{},
    watch:{}
}
</script>