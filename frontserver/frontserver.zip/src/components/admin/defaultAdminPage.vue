<template>
<div>
    <h1>관리자 페이지</h1>
</div>
</template>


<script>
export default{ 
    name:'',
    components:{},
    computed:{},
    data(){
        return{
            
        };
    },
    setup(){},
    created(){},
    mounted(){},
    unmounted(){},
    methods:{},
    watch:{}
}
</script>